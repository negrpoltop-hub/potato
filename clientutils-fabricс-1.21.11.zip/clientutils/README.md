# ClientUtils (Fabric 1.21.11)
Клиентский мод: Fly, Speed, ESP, Fullbright, AutoSprint, KillAura, Aimbot + HUD + GUI.

Сборка: `gradle wrapper` (один раз), затем `./gradlew build` -> build/libs/clientutils-1.0.0.jar
Запуск для теста: `./gradlew runClient`
Меню: Ctrl+Shift+I. Полёт: клавиша G (Space вверх, Shift вниз).

Версии в gradle.properties сверь на https://fabricmc.net/develop
Используй в одиночной игре или на своих серверах: на публичных серверах такие функции банятся.
