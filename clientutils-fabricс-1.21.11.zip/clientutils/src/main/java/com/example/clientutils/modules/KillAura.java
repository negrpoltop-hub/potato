package com.example.clientutils.modules;

import com.example.clientutils.Module;
import com.example.clientutils.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;

public class KillAura extends Module {
    private static final double RANGE = 10.0;

    public KillAura() { super("KillAura"); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.interactionManager == null || mc.currentScreen != null) return;
        var p = mc.player;
        if (p.getAttackCooldownProgress(0.5f) < 1.0f) return;

        LivingEntity target = Targets.find(mc, RANGE);
        if (target == null) return;

        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
    }
}
