package com.example.clientutils;

import com.example.clientutils.modules.Fly;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class ClientUtilsClient implements ClientModInitializer {
    public static KeyBinding menuKey;
    public static KeyBinding flyKey;

    @Override
    public void onInitializeClient() {
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("clientutils", "main"));

        // Меню: Ctrl + Shift + I
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.clientutils.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_I, category));
        // Быстрое включение полёта: G
        flyKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.clientutils.fly", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, category));

        ModuleManager.init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (Screen.hasControlDown() && Screen.hasShiftDown()) {
                    client.setScreen(new ModuleScreen());
                }
            }
            while (flyKey.wasPressed()) {
                if (client.currentScreen == null) {
                    ModuleManager.get(Fly.class).toggle();
                }
            }
            if (client.player != null && client.world != null) {
                ModuleManager.tick(client);
            }
        });

        HudRenderCallback.EVENT.register(Hud::render);
    }
}
