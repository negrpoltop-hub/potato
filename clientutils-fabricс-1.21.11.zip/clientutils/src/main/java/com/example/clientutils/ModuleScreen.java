package com.example.clientutils;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class ModuleScreen extends Screen {
    public ModuleScreen() {
        super(Text.literal("ClientUtils"));
    }

    @Override
    protected void init() {
        int w = 140, h = 20, gap = 4;
        int total = ModuleManager.MODULES.size() * (h + gap);
        int y = this.height / 2 - total / 2;
        for (Module m : ModuleManager.MODULES) {
            ButtonWidget btn = ButtonWidget.builder(label(m), b -> {
                m.toggle();
                b.setMessage(label(m));
            }).dimensions(this.width / 2 - w / 2, y, w, h).build();
            this.addDrawableChild(btn);
            y += h + gap;
        }
    }

    private static Text label(Module m) {
        return Text.literal(m.name + ": " + (m.isEnabled() ? "§aON" : "§cOFF"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 0xFFFFFFFF);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
