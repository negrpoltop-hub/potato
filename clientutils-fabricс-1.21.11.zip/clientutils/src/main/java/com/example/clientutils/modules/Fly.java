package com.example.clientutils.modules;

import com.example.clientutils.Module;
import net.minecraft.client.MinecraftClient;

/** Полёт: WASD по направлению взгляда, Space вверх, Shift вниз. */
public class Fly extends Module {
    private static final double SPEED = 0.9;

    public Fly() { super("Fly"); }

    @Override
    public void onTick(MinecraftClient mc) {
        var p = mc.player;

        double f = Math.signum(p.forwardSpeed);
        double s = Math.signum(p.sidewaysSpeed);
        double yaw = Math.toRadians(p.getYaw());

        double x = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        double z = Math.cos(yaw) * f + Math.sin(yaw) * s;
        double len = Math.hypot(x, z);
        if (len > 1e-4) {
            x = x / len * SPEED;
            z = z / len * SPEED;
        } else {
            x = 0;
            z = 0;
        }

        double y = 0;
        if (mc.options.jumpKey.isPressed()) y += SPEED;
        if (mc.options.sneakKey.isPressed()) y -= SPEED;

        p.setVelocity(x, y, z);
    }
}
