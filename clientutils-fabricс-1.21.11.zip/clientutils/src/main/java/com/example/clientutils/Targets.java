package com.example.clientutils;

import com.example.clientutils.modules.TargetPlayers;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;

public class Targets {
    /** Ближайшая подходящая цель в радиусе range. По умолчанию только враждебные мобы. */
    public static LivingEntity find(MinecraftClient mc, double range) {
        boolean players = ModuleManager.get(TargetPlayers.class).isEnabled();
        LivingEntity best = null;
        double bestDist = range * range;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == mc.player) continue;
            if (!le.isAlive() || le instanceof ArmorStandEntity) continue;

            boolean ok = (le instanceof Monster) || (players && le instanceof PlayerEntity);
            if (!ok) continue;
            if (!mc.player.canSee(le)) continue;

            double d = mc.player.squaredDistanceTo(le);
            if (d < bestDist) {
                bestDist = d;
                best = le;
            }
        }
        return best;
    }
}
