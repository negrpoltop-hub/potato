package com.example.clientutils.modules;

import com.example.clientutils.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

public class Speed extends Module {
    private static final double MULTIPLIER = 1.6;
    private static final double MAX_HORIZONTAL = 0.6;

    public Speed() { super("Speed"); }

    @Override
    public void onTick(MinecraftClient mc) {
        var p = mc.player;
        boolean moving = p.forwardSpeed != 0 || p.sidewaysSpeed != 0;
        if (!moving || !p.isOnGround()) return;

        Vec3d v = p.getVelocity();
        double hx = v.x * MULTIPLIER, hz = v.z * MULTIPLIER;
        double len = Math.hypot(hx, hz);
        if (len > MAX_HORIZONTAL) {
            hx = hx / len * MAX_HORIZONTAL;
            hz = hz / len * MAX_HORIZONTAL;
        }
        p.setVelocity(hx, v.y, hz);
    }
}
