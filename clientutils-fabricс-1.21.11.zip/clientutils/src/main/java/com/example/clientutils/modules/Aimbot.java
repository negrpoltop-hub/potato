package com.example.clientutils.modules;

import com.example.clientutils.Module;
import com.example.clientutils.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Aimbot extends Module {
    private static final double RANGE = 6.0;
    private static final float MAX_STEP = 18f; // градусов за тик (плавное наведение)

    public Aimbot() { super("Aimbot"); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null) return;
        var p = mc.player;

        LivingEntity target = Targets.find(mc, RANGE);
        if (target == null) return;

        Vec3d eye = p.getEyePos();
        Vec3d aim = target.getBoundingBox().getCenter();
        double dx = aim.x - eye.x;
        double dy = aim.y - eye.y;
        double dz = aim.z - eye.z;

        float wantYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));

        float dYaw = MathHelper.clamp(MathHelper.wrapDegrees(wantYaw - p.getYaw()), -MAX_STEP, MAX_STEP);
        float dPitch = MathHelper.clamp(wantPitch - p.getPitch(), -MAX_STEP, MAX_STEP);

        p.setYaw(p.getYaw() + dYaw);
        p.setPitch(MathHelper.clamp(p.getPitch() + dPitch, -90f, 90f));
    }
}
