package com.example.clientutils.modules;

import com.example.clientutils.Module;

/** Переключатель: включать ли игроков в цели KillAura / Aimbot (по умолчанию выкл — только мобы). */
public class TargetPlayers extends Module {
    public TargetPlayers() { super("Target Players"); }
}
