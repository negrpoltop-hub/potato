package com.example.clientutils;

import com.example.clientutils.modules.Fly;
import com.example.clientutils.modules.Rage;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class ClientUtilsClient implements ClientModInitializer {
    public static KeyBinding menuKey;
    public static KeyBinding flyKey;
    public static KeyBinding rageKey;

    @Override
    public void onInitializeClient() {
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("clientutils", "main"));

        // Меню: Ctrl + Shift + I
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.clientutils.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_I, category));
        // Быстрое включение полёта: G
        flyKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.clientutils.fly", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, category));

        // Rage-режим: R
        rageKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.clientutils.rage", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, category));

        ModuleManager.init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (isDown(client, GLFW.GLFW_KEY_LEFT_CONTROL, GLFW.GLFW_KEY_RIGHT_CONTROL)
                        && isDown(client, GLFW.GLFW_KEY_LEFT_SHIFT, GLFW.GLFW_KEY_RIGHT_SHIFT)) {
                    client.setScreen(new ModuleScreen());
                }
            }
            while (flyKey.wasPressed()) {
                if (client.currentScreen == null) {
                    ModuleManager.get(Fly.class).toggle();
                }
            }
            while (rageKey.wasPressed()) {
                if (client.currentScreen == null) {
                    ModuleManager.get(Rage.class).toggle();
                }
            }
            if (client.player != null && client.world != null) {
                ModuleManager.tick(client);
            }
        });

        // Запоминаем, кого ты ударил (для Auto Target и Follow Fly)
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            Targets.onAttack(entity);
            return ActionResult.PASS;
        });

        HudRenderCallback.EVENT.register(Hud::render);
    }

    private static boolean isDown(MinecraftClient client, int keyA, int keyB) {
        long handle = client.getWindow().getHandle();
        return GLFW.glfwGetKey(handle, keyA) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(handle, keyB) == GLFW.GLFW_PRESS;
    }
}
