package com.example.clientutils.modules;

import com.example.clientutils.Module;
import com.example.clientutils.NumberSetting;
import com.example.clientutils.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Автополёт за игроком, которого ты ударил последним. */
public class FollowFly extends Module {
    private final NumberSetting speed = num("Speed", 0.9, 0.1, 3.0, 0.1);
    private final NumberSetting stopDist = num("Stop distance", 2.5, 1.0, 10.0, 0.5);
    private final NumberSetting maxDist = num("Max distance", 64, 8, 256, 8);

    public FollowFly() { super("Follow Fly"); }

    @Override
    public void onTick(MinecraftClient mc) {
        LivingEntity t = Targets.lastAttacked;
        if (!(t instanceof PlayerEntity) || !t.isAlive() || t.isRemoved()) return;

        var p = mc.player;
        double dx = t.getX() - p.getX();
        double dy = t.getY() - p.getY();
        double dz = t.getZ() - p.getZ();
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist > maxDist.get()) return;

        double stop = stopDist.get();
        if (dist <= stop) {
            p.setVelocity(0, 0, 0);
            return;
        }
        double v = Math.min(speed.get(), dist - stop + 0.1);
        p.setVelocity(dx / dist * v, dy / dist * v, dz / dist * v);
    }
}
