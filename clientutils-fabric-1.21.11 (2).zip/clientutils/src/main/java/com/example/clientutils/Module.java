package com.example.clientutils;

import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public final List<Setting> settings = new ArrayList<>();
    private boolean enabled;

    protected Module(String name) {
        this.name = name;
    }

    protected NumberSetting num(String n, double def, double min, double max, double step) {
        NumberSetting s = new NumberSetting(n, def, min, max, step);
        settings.add(s);
        return s;
    }

    protected BoolSetting bool(String n, boolean def) {
        BoolSetting s = new BoolSetting(n, def);
        settings.add(s);
        return s;
    }

    public boolean isEnabled() { return enabled; }

    public void toggle() {
        enabled = !enabled;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (enabled) onEnable(mc); else onDisable(mc);
    }

    protected void onEnable(MinecraftClient mc) {}
    protected void onDisable(MinecraftClient mc) {}
    public void onTick(MinecraftClient mc) {}
}
