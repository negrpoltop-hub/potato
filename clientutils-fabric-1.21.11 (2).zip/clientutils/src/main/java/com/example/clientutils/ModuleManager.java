package com.example.clientutils;

import com.example.clientutils.modules.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();

    public static void init() {
        MODULES.add(new Fly());
        MODULES.add(new Speed());
        MODULES.add(new Esp());
        MODULES.add(new Fullbright());
        MODULES.add(new AutoSprint());
        MODULES.add(new KillAura());
        MODULES.add(new Aimbot());
        MODULES.add(new TargetPlayers());
        MODULES.add(new AutoTarget());
        MODULES.add(new FollowFly());
        MODULES.add(new Rage());
        load();
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> cls) {
        for (Module m : MODULES) {
            if (cls.isInstance(m)) return (T) m;
        }
        throw new IllegalStateException("Module not found: " + cls);
    }

    public static void tick(MinecraftClient mc) {
        for (Module m : MODULES) {
            if (m.isEnabled()) m.onTick(mc);
        }
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("clientutils.properties");
    }

    public static void save() {
        Properties props = new Properties();
        for (Module m : MODULES) {
            for (Setting s : m.settings) {
                props.setProperty(m.name + "." + s.name, s.serialize());
            }
        }
        try (OutputStream out = Files.newOutputStream(file())) {
            props.store(out, "ClientUtils settings");
        } catch (IOException ignored) {}
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(f)) {
            props.load(in);
        } catch (IOException e) {
            return;
        }
        for (Module m : MODULES) {
            for (Setting s : m.settings) {
                String v = props.getProperty(m.name + "." + s.name);
                if (v != null) s.load(v);
            }
        }
    }
}
