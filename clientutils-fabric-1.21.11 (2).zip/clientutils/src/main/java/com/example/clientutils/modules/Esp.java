package com.example.clientutils.modules;

import com.example.clientutils.BoolSetting;
import com.example.clientutils.Module;
import com.example.clientutils.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;

import java.util.HashSet;
import java.util.Set;

public class Esp extends Module {
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting hostile = bool("Hostile mobs", true);
    private final BoolSetting passive = bool("Passive mobs", true);
    private final NumberSetting range = num("Range", 64, 8, 128, 8);
    private final Set<Integer> glowed = new HashSet<>();

    public Esp() { super("ESP"); }

    @Override
    public void onTick(MinecraftClient mc) {
        double r2 = range.get() * range.get();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity) || e == mc.player) continue;

            boolean isPlayer = e instanceof PlayerEntity;
            boolean isHostile = e instanceof Monster;
            boolean want = mc.player.squaredDistanceTo(e) <= r2
                    && ((isPlayer && players.get())
                    || (isHostile && hostile.get())
                    || (!isPlayer && !isHostile && passive.get()));

            if (want) {
                e.setGlowing(true);
                glowed.add(e.getId());
            } else if (glowed.remove(e.getId())) {
                e.setGlowing(false);
            }
        }
    }

    @Override
    protected void onDisable(MinecraftClient mc) {
        if (mc.world != null) {
            for (Entity e : mc.world.getEntities()) {
                if (glowed.contains(e.getId())) e.setGlowing(false);
            }
        }
        glowed.clear();
    }
}
