package com.example.clientutils.modules;

import com.example.clientutils.BoolSetting;
import com.example.clientutils.Module;
import com.example.clientutils.ModuleManager;
import com.example.clientutils.NumberSetting;
import com.example.clientutils.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;

import java.util.List;

public class KillAura extends Module {
    private final NumberSetting range = num("Range", 10, 3, 12, 0.5);
    private final BoolSetting waitCooldown = bool("Wait cooldown", true);
    private final BoolSetting multi = bool("Multi target", false);
    private final NumberSetting delay = num("Delay (ticks)", 0, 0, 20, 1);
    private final BoolSetting swing = bool("Swing hand", true);
    private int ticks;

    public KillAura() { super("KillAura"); }

    @Override
    public void onTick(MinecraftClient mc) {
        ticks++;
        if (mc.interactionManager == null || mc.currentScreen != null) return;
        var p = mc.player;

        Rage rage = ModuleManager.get(Rage.class);
        boolean rageOn = rage.isEnabled();
        boolean wait = waitCooldown.get() && !rageOn;
        boolean multiMode = multi.get() || (rageOn && rage.multi.get());

        if (wait && p.getAttackCooldownProgress(0.5f) < 1.0f) return;
        if (ticks < delay.getInt()) return;

        List<LivingEntity> targets;
        if (multiMode) {
            targets = Targets.findAll(mc, range.get());
        } else {
            LivingEntity t = Targets.find(mc, range.get());
            targets = t == null ? List.of() : List.of(t);
        }
        if (targets.isEmpty()) return;

        ticks = 0;
        for (LivingEntity t : targets) {
            mc.interactionManager.attackEntity(p, t);
        }
        Targets.onAttack(targets.get(0));
        if (swing.get()) p.swingHand(Hand.MAIN_HAND);
    }
}
