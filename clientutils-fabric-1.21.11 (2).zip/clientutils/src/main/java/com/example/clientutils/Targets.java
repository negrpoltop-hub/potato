package com.example.clientutils;

import com.example.clientutils.modules.AutoTarget;
import com.example.clientutils.modules.TargetPlayers;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Targets {
    public static LivingEntity locked;
    public static LivingEntity lastAttacked;

    public static void onAttack(Entity e) {
        if (!(e instanceof LivingEntity le) || le instanceof ArmorStandEntity) return;
        lastAttacked = le;
        AutoTarget at = ModuleManager.get(AutoTarget.class);
        if (at.isEnabled() && at.preferLast.get()) {
            locked = le;
        }
    }

    public static List<LivingEntity> findAll(MinecraftClient mc, double range) {
        TargetPlayers tp = ModuleManager.get(TargetPlayers.class);
        boolean players = tp.isEnabled();
        boolean passive = tp.passive.get();
        boolean walls = tp.throughWalls.get();
        double r2 = range * range;
        List<LivingEntity> out = new ArrayList<>();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == mc.player) continue;
            if (!le.isAlive() || le instanceof ArmorStandEntity) continue;

            boolean isPlayer = le instanceof PlayerEntity;
            boolean isHostile = le instanceof Monster;
            boolean ok = isHostile || (isPlayer && players) || (!isPlayer && !isHostile && passive);
            if (!ok) continue;
            if (mc.player.squaredDistanceTo(le) > r2) continue;
            if (!walls && !mc.player.canSee(le)) continue;
            out.add(le);
        }
        out.sort(Comparator.comparingDouble(mc.player::squaredDistanceTo));
        return out;
    }

    public static LivingEntity find(MinecraftClient mc, double range) {
        AutoTarget at = ModuleManager.get(AutoTarget.class);
        boolean auto = at.isEnabled();

        if (auto && locked != null) {
            double keep = range * at.keepRange.get();
            if (locked.isAlive() && !locked.isRemoved() && mc.player.squaredDistanceTo(locked) <= keep * keep) {
                return locked;
            }
            locked = null;
        }

        List<LivingEntity> all = findAll(mc, range);
        LivingEntity best = all.isEmpty() ? null : all.get(0);
        if (auto) locked = best;
        return best;
    }
}
