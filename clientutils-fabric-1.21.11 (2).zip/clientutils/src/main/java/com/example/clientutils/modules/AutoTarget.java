package com.example.clientutils.modules;

import com.example.clientutils.BoolSetting;
import com.example.clientutils.Module;
import com.example.clientutils.NumberSetting;
import com.example.clientutils.Targets;
import net.minecraft.client.MinecraftClient;

/** Авто-таргет: модули держатся за одну цель, пока она жива и рядом. */
public class AutoTarget extends Module {
    public final NumberSetting keepRange = num("Keep range (x)", 1.5, 1.0, 3.0, 0.1);
    public final BoolSetting preferLast = bool("Lock on attacked", true);

    public AutoTarget() { super("Auto Target"); }

    @Override
    protected void onDisable(MinecraftClient mc) {
        Targets.locked = null;
    }
}
