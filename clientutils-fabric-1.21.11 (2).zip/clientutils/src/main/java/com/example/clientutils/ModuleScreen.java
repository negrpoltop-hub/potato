package com.example.clientutils;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public class ModuleScreen extends Screen {
    private static int selected = 0;
    private static int scroll = 0;

    private int rightX, top;

    public ModuleScreen() {
        super(Text.literal("ClientUtils"));
    }

    @Override
    protected void init() {
        int rowH = 20;
        top = 34;
        int left = this.width / 2 - 175;
        rightX = left + 155;

        int total = ModuleManager.MODULES.size();
        int visible = Math.max(3, (this.height - top - 16) / rowH);
        scroll = Math.max(0, Math.min(scroll, Math.max(0, total - visible)));
        if (selected >= total) selected = 0;

        for (int i = scroll; i < Math.min(total, scroll + visible); i++) {
            final int index = i;
            final Module m = ModuleManager.MODULES.get(i);
            int y = top + (i - scroll) * rowH;

            this.addDrawableChild(ButtonWidget.builder(label(m), b -> {
                m.toggle();
                b.setMessage(label(m));
            }).dimensions(left, y, 120, 18).build());

            this.addDrawableChild(ButtonWidget.builder(Text.literal(index == selected ? "§e>" : ">"), b -> {
                selected = index;
                this.clearAndInit();
            }).dimensions(left + 122, y, 22, 18).build());
        }

        Module sel = ModuleManager.MODULES.get(selected);
        int y = top;
        for (Setting s : sel.settings) {
            if (s instanceof NumberSetting ns) {
                this.addDrawableChild(new SettingSlider(rightX, y, 190, 18, ns));
            } else if (s instanceof BoolSetting bs) {
                this.addDrawableChild(ButtonWidget.builder(boolLabel(bs), b -> {
                    bs.toggle();
                    b.setMessage(boolLabel(bs));
                }).dimensions(rightX, y, 190, 18).build());
            }
            y += 22;
        }
    }

    private static Text label(Module m) {
        return Text.literal(m.name + ": " + (m.isEnabled() ? "§aON" : "§cOFF"));
    }

    private static Text boolLabel(BoolSetting s) {
        return Text.literal(s.name + ": " + (s.get() ? "§aON" : "§cOFF"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 12, 0xFFFFFFFF);

        Module sel = ModuleManager.MODULES.get(selected);
        ctx.drawTextWithShadow(this.textRenderer, "Settings: " + sel.name, rightX, top - 12, 0xFF55FFFF);
        if (sel.settings.isEmpty()) {
            ctx.drawTextWithShadow(this.textRenderer, "No settings", rightX, top + 4, 0xFFAAAAAA);
        }
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (mouseX < rightX - 10) {
            scroll -= (int) Math.signum(verticalAmount);
            this.clearAndInit();
            return true;
        }
        return false;
    }

    public void close() {
        ModuleManager.save();
        super.close();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static class SettingSlider extends SliderWidget {
        private final NumberSetting setting;

        SettingSlider(int x, int y, int w, int h, NumberSetting setting) {
            super(x, y, w, h, Text.empty(), setting.toNorm());
            this.setting = setting;
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            if (setting == null) return;
            setMessage(Text.literal(setting.name + ": " + setting.display()));
        }

        @Override
        protected void applyValue() {
            setting.setNorm(this.value);
            updateMessage();
        }
    }
}
