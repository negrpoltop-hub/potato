package com.example.clientutils;

public class BoolSetting extends Setting {
    private boolean value;

    public BoolSetting(String name, boolean def) {
        super(name);
        this.value = def;
    }

    public boolean get() { return value; }

    public void toggle() { value = !value; }

    @Override
    public String serialize() { return Boolean.toString(value); }

    @Override
    public void load(String raw) { value = Boolean.parseBoolean(raw); }
}
