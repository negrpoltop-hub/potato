package com.example.clientutils;

public class NumberSetting extends Setting {
    public final double min, max, step;
    private double value;

    public NumberSetting(String name, double def, double min, double max, double step) {
        super(name);
        this.min = min;
        this.max = max;
        this.step = step;
        set(def);
    }

    public double get() { return value; }

    public int getInt() { return (int) Math.round(value); }

    public void set(double v) {
        v = Math.max(min, Math.min(max, v));
        v = Math.round(v / step) * step;
        v = Math.round(v * 1000.0) / 1000.0;
        value = Math.max(min, Math.min(max, v));
    }

    public double toNorm() { return (value - min) / (max - min); }

    public void setNorm(double n) { set(min + n * (max - min)); }

    public String display() {
        return step >= 1 ? String.valueOf(Math.round(value)) : String.format("%.2f", value);
    }

    @Override
    public String serialize() { return Double.toString(value); }

    @Override
    public void load(String raw) {
        try { set(Double.parseDouble(raw)); } catch (NumberFormatException ignored) {}
    }
}
