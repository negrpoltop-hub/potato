package com.example.clientutils.modules;

import com.example.clientutils.BoolSetting;
import com.example.clientutils.Module;
import net.minecraft.client.MinecraftClient;

public class AutoSprint extends Module {
    private final BoolSetting stopOnCollision = bool("Stop on collision", true);
    private final BoolSetting notSneaking = bool("Not while sneaking", true);

    public AutoSprint() { super("AutoSprint"); }

    @Override
    public void onTick(MinecraftClient mc) {
        var p = mc.player;
        if (p.forwardSpeed <= 0) return;
        if (stopOnCollision.get() && p.horizontalCollision) return;
        if (notSneaking.get() && p.isSneaking()) return;
        p.setSprinting(true);
    }
}
