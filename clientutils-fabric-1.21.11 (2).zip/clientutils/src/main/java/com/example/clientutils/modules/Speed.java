package com.example.clientutils.modules;

import com.example.clientutils.BoolSetting;
import com.example.clientutils.Module;
import com.example.clientutils.ModuleManager;
import com.example.clientutils.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

public class Speed extends Module {
    private final NumberSetting mult = num("Multiplier", 1.6, 1.0, 5.0, 0.1);
    private final NumberSetting maxSpeed = num("Max speed", 0.6, 0.2, 2.0, 0.05);
    private final BoolSetting onGround = bool("Only on ground", true);

    public Speed() { super("Speed"); }

    @Override
    public void onTick(MinecraftClient mc) {
        var p = mc.player;
        boolean moving = p.forwardSpeed != 0 || p.sidewaysSpeed != 0;
        if (!moving) return;
        if (onGround.get() && !p.isOnGround()) return;

        Rage r = ModuleManager.get(Rage.class);
        double boost = r.isEnabled() ? r.boost.get() : 1.0;
        double mul = mult.get() * boost;
        double max = maxSpeed.get() * boost;

        Vec3d v = p.getVelocity();
        double hx = v.x * mul, hz = v.z * mul;
        double len = Math.hypot(hx, hz);
        if (len > max) {
            hx = hx / len * max;
            hz = hz / len * max;
        }
        p.setVelocity(hx, v.y, hz);
    }
}
