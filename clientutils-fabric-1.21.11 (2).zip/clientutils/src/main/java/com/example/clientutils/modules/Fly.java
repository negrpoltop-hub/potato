package com.example.clientutils.modules;

import com.example.clientutils.Module;
import com.example.clientutils.NumberSetting;
import net.minecraft.client.MinecraftClient;

/** Полёт: WASD по направлению взгляда, Space вверх, Shift вниз. */
public class Fly extends Module {
    private final NumberSetting speed = num("Speed", 0.9, 0.1, 3.0, 0.1);
    private final NumberSetting vSpeed = num("Vertical speed", 0.9, 0.1, 3.0, 0.1);

    public Fly() { super("Fly"); }

    @Override
    public void onTick(MinecraftClient mc) {
        var p = mc.player;

        double f = Math.signum(p.forwardSpeed);
        double s = Math.signum(p.sidewaysSpeed);
        double yaw = Math.toRadians(p.getYaw());

        double x = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        double z = Math.cos(yaw) * f + Math.sin(yaw) * s;
        double len = Math.hypot(x, z);
        if (len > 1e-4) {
            x = x / len * speed.get();
            z = z / len * speed.get();
        } else {
            x = 0;
            z = 0;
        }

        double y = 0;
        if (mc.options.jumpKey.isPressed()) y += vSpeed.get();
        if (mc.options.sneakKey.isPressed()) y -= vSpeed.get();

        p.setVelocity(x, y, z);
    }
}
