package com.example.clientutils.modules;

import com.example.clientutils.BoolSetting;
import com.example.clientutils.Module;

/** Включено = в цели KillAura/Aimbot входят игроки. Настройки задают и прочие правила выбора целей. */
public class TargetPlayers extends Module {
    public final BoolSetting passive = bool("Passive mobs", false);
    public final BoolSetting throughWalls = bool("Through walls", false);

    public TargetPlayers() { super("Target Players"); }
}
