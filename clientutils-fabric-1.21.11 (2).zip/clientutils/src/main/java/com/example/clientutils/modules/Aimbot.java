package com.example.clientutils.modules;

import com.example.clientutils.BoolSetting;
import com.example.clientutils.Module;
import com.example.clientutils.ModuleManager;
import com.example.clientutils.NumberSetting;
import com.example.clientutils.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Aimbot extends Module {
    private final NumberSetting range = num("Range", 10, 3, 20, 0.5);
    private final NumberSetting speed = num("Turn speed (deg/tick)", 18, 1, 180, 1);
    private final BoolSetting head = bool("Aim at head", false);
    private final BoolSetting vertical = bool("Vertical aim", true);

    public Aimbot() { super("Aimbot"); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.currentScreen != null) return;
        var p = mc.player;

        LivingEntity target = Targets.find(mc, range.get());
        if (target == null) return;

        Rage rage = ModuleManager.get(Rage.class);
        float maxStep = (rage.isEnabled() && rage.snap.get()) ? 180f : (float) speed.get();

        Vec3d eye = p.getEyePos();
        Vec3d aim = head.get() ? target.getEyePos() : target.getBoundingBox().getCenter();
        double dx = aim.x - eye.x;
        double dy = aim.y - eye.y;
        double dz = aim.z - eye.z;

        float wantYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));

        float dYaw = MathHelper.clamp(MathHelper.wrapDegrees(wantYaw - p.getYaw()), -maxStep, maxStep);
        p.setYaw(p.getYaw() + dYaw);

        if (vertical.get()) {
            float dPitch = MathHelper.clamp(wantPitch - p.getPitch(), -maxStep, maxStep);
            p.setPitch(MathHelper.clamp(p.getPitch() + dPitch, -90f, 90f));
        }
    }
}
