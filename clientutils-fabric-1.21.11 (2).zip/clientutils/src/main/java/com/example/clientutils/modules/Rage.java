package com.example.clientutils.modules;

import com.example.clientutils.BoolSetting;
import com.example.clientutils.Module;
import com.example.clientutils.ModuleManager;
import com.example.clientutils.NumberSetting;
import net.minecraft.client.MinecraftClient;

/** Rage-режим: включает связку модулей и усиливает их. */
public class Rage extends Module {
    public final NumberSetting boost = num("Speed boost (x)", 1.4, 1.0, 3.0, 0.1);
    public final BoolSetting snap = bool("Instant aim", true);
    public final BoolSetting multi = bool("Hit all targets", true);

    public Rage() { super("RAGE MODE"); }

    private static Module[] pack() {
        return new Module[] {
                ModuleManager.get(KillAura.class),
                ModuleManager.get(Aimbot.class),
                ModuleManager.get(Speed.class),
                ModuleManager.get(Fly.class),
                ModuleManager.get(Esp.class),
                ModuleManager.get(AutoSprint.class),
                ModuleManager.get(Fullbright.class),
                ModuleManager.get(AutoTarget.class),
                ModuleManager.get(FollowFly.class)
        };
    }

    @Override
    protected void onEnable(MinecraftClient mc) {
        for (Module m : pack()) {
            if (!m.isEnabled()) m.toggle();
        }
    }

    @Override
    protected void onDisable(MinecraftClient mc) {
        for (Module m : pack()) {
            if (m.isEnabled()) m.toggle();
        }
    }
}
